'use strict';

/**
 * @ngdoc overview
 * @name carouselApp
 * @description
 * # carouselApp
 *
 * Main module of the application.
 */
angular
  .module('carouselApp', [
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch'
  ]);
