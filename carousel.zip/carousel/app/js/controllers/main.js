'use strict';

/**
 * @ngdoc function
 * @name carouselApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the carouselApp
 */
angular.module('carouselApp')
  .controller('MainCtrl', function ($scope, $http) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];

    $http.get('fixtures/ridings.json').success(function(data){
	   	$scope.ridings = data;
	});

	$scope.percentage = function(party, candidates){
		var total = 0;
		angular.forEach(candidates, function(candidate, key) {
			total += candidate['votes'];
		});
		return (party.votes/total) * 100;
	}

	$scope.isElected = function(party, candidates){
		var hasHighest = false;
		var highestVotes = 0;
		angular.forEach(candidates, function(candidate, key){
			if (candidate['votes'] > highestVotes){
				highestVotes = candidate['votes'];
			}
		});

		return (party['votes'] === highestVotes) ? 'Elected' : '';

	}

	$scope.nextRiding = function(){
		var $table = $(angular.element.find('#resultsTables')[0]);
		var px = parseInt($table.attr('data-x'), 10) - 400;
	
		if (px <= (-4000)){
			px = 0;
		
			$table.css({
	  			'transition': 'transform 0.5s',
	  			'transform': 'translate3d('+px+'px, 0px, 0px)'
			});
		} else {
			$table.css({
	  			'transition': 'transform 1s',
	  			'transform': 'translate3d('+px+'px, 0px, 0px)'
			});
		}
			$table.attr('data-x', px);	
	}

	$scope.prevRiding = function(){
		var $table= $(angular.element.find('#resultsTables')[0]);
		var px = parseInt($table.attr('data-x'), 10) + 400;

		if (px > 0){
			px = -3600;
		
			$table.css({
  				'transition': 'transform 0.2s',
  				'transform': 'translate3d('+px+'px, 0px, 0px)'
			});
		} else {
			$table.css({
	  			'transition': 'transform 1s',
	  			'transform': 'translate3d('+px+'px, 0px, 0px)'
			});
		}	

		$table.attr('data-x', px);
	}



});
